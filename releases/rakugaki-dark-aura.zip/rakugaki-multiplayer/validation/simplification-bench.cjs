'use strict';
// CPU-only benchmark; no network traffic. Usage: node simplification-bench.cjs ROOT OUTPUT
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),Module=require('node:module');
const root=path.resolve(process.argv[2]),output=path.resolve(process.argv[3]);
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'raku-simplify-bench-'));process.env.DATA_DIR=dir;
const m=new Module(path.join(root,'server.cjs'),module);m.filename=path.join(root,'server.cjs');m.paths=Module._nodeModulePaths(root);
m._compile(fs.readFileSync(m.filename,'utf8')+'\nclearInterval(loop);clearInterval(ping);',m.filename);
const world=m.exports;
const median=xs=>xs.sort((a,b)=>a-b)[Math.floor(xs.length/2)];
(async()=>{try{
 const publication=[];
 for(const clients of [1,20,100]){
  let bytes=0;
  const peers=Array.from({length:clients},(_,i)=>({accountId:'bench-'+i,readyState:1,bufferedAmount:0,send(json){bytes+=Buffer.byteLength(json)}}));
  for(let i=0;i<5;i++)world.publish(peers);
  const times=[];for(let i=0;i<25;i++){bytes=0;const start=performance.now();world.publish(peers);times.push(performance.now()-start)}
  publication.push({clients,medianMs:median(times),bytesPerPublication:bytes,samples:times});
 }
 const accounts=[];
 for(const count of [1000,10000]){
  world.accounts.clear();for(let i=0;i<count;i++)world.accounts.set('bench-'+i,{id:'bench-'+i,team:37,arts:[{id:'fixture-art'}]});
  for(let i=0;i<3;i++)world.sim().cpuMax(37);
  const times=[];for(let i=0;i<25;i++){const start=performance.now();for(let j=0;j<20;j++)world.sim().cpuMax(37);times.push(performance.now()-start)}
  accounts.push({count,callsPerSample:20,medianMs:median(times),samples:times});
 }
 const result={node:process.version,publication,accounts};fs.writeFileSync(output,JSON.stringify(result,null,2));console.log(JSON.stringify(result,(k,v)=>k==='samples'?undefined:v,2));
}finally{await world.close();fs.rmSync(dir,{recursive:true,force:true})}})().then(()=>process.exit(0)).catch(error=>{console.error(error);process.exit(1)});
