'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),WebSocket=require('ws');
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'rakugaki-'));process.env.DATA_DIR=dir;
const world=require('../server.cjs');
const next=(ws,p)=>new Promise((resolve,reject)=>{const timeout=setTimeout(()=>reject(Error('timeout')),16000);
 function cb(data){const m=JSON.parse(data);if(p(m)){clearTimeout(timeout);ws.off('message',cb);resolve(m)}}ws.on('message',cb)});
async function connect(port,cookie){const ws=new WebSocket('ws://127.0.0.1:'+port+'/ws',{headers:{Cookie:cookie}});await new Promise(ok=>ws.once('open',ok));return ws}
(async()=>{
 await new Promise(ok=>world.server.listen(0,'127.0.0.1',ok));const port=world.server.address().port,url='http://127.0.0.1:'+port;
 const r1=await fetch(url+'/api/session'),r2=await fetch(url+'/api/session'),a=await r1.json(),b=await r2.json();
 assert.equal(a.artLimit,6);assert.notEqual(a.accountId,b.accountId);
 const w1=await connect(port,r1.headers.get('set-cookie').split(';')[0]),w2=await connect(port,r2.headers.get('set-cookie').split(';')[0]);
 let p=next(w1,x=>x.type==='ready');w1.send(JSON.stringify({type:'init'}));const s1=await p;assert.equal(s1.owner.length,1310400);
 p=next(w2,x=>x.type==='ready');w2.send(JSON.stringify({type:'init'}));const s2=await p;assert(s2.time>=s1.time);
 p=next(w1,x=>x.type==='teamResult');w1.send(JSON.stringify({type:'selectTeam',team:37}));assert((await p).ok);
 p=next(w2,x=>x.type==='teamResult');w2.send(JSON.stringify({type:'selectTeam',team:38}));assert((await p).ok);
 const c=world.sim().cities.find(x=>x.owner===37&&!x.home);
 const png=new (require('pngjs').PNG)({width:8,height:8});png.data.fill(255);const image='data:image/png;base64,'+require('pngjs').PNG.sync.write(png).toString('base64');
 p=next(w1,x=>x.type==='summonResult');w1.send(JSON.stringify({type:'summon',team:37,cityId:c.id,role:'melee',image,pixels:8}));
 const result=await p;assert(result.ok,result.error);assert.equal(world.sim().units.get(result.id).accountId,a.accountId);
 p=next(w2,x=>x.type==='ordersResult');w2.send(JSON.stringify({type:'playerOrders',ids:[result.id],team:38,tile:result.tile,mode:'free'}));assert(!(await p).ok);
 const account=world.accounts.get(a.accountId);account.kills=450;assert.equal(world.capacity(account),24);
 w1.terminate();w2.terminate();await world.close();fs.rmSync(dir,{recursive:true,force:true});console.log('Integration PASS');
})().catch(e=>{console.error(e);process.exitCode=1;world.close().catch(()=>{})});
