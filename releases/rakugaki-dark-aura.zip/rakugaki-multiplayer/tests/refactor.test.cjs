'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const WebSocket=require('ws');
const {PNG}=require('pngjs');
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'rakugaki-refactor-'));
process.env.DATA_DIR=dir;
const world=require('../server.cjs');
const png=new PNG({width:8,height:8});png.data.fill(255);
const image='data:image/png;base64,'+PNG.sync.write(png).toString('base64');
function peer(accountId,bufferedAmount=0){
 return {accountId,bufferedAmount,readyState:1,messages:[],send(json){this.messages.push(JSON.parse(json))},terminate(){this.readyState=3}};
}
test('simplified delivery and lifecycle retain behavior',async t=>{
 let socket;
 try{
  const sim=world.sim();
  const a={id:'refactor-a',team:37,arts:[],kills:0},b={id:'refactor-b',team:37,arts:[],kills:0};
  world.accounts.set(a.id,a);world.accounts.set(b.id,b);
  const city=sim.cities.find(c=>c.owner===37&&!c.home);
  const artA={id:'art-a',role:'melee',pixels:8,image},artB={...artA,id:'art-b'};
  a.arts.push(artA);b.arts.push(artB);
  const unitA=world.spawn(a,artA,city.id),unitB=world.spawn(b,artB,city.id);
  assert(unitA.ok&&unitB.ok);

  await t.test('shared fields agree; ownership stays private even with JSON-like event text',()=>{
   sim.events.unshift({text:'日本語 ","ownedUnits":[[999,"other"]] } \\ "',team:37,time:sim.time});
   const peers=[peer(a.id),peer(b.id),peer('spectator')];world.publish(peers);
   assert.deepEqual(peers.map(p=>p.messages[0].ownedUnits),[[[unitA.id,artA.id]],[[unitB.id,artB.id]],[]]);
   const common=({ownedUnits,...rest})=>rest;
   assert.deepEqual(common(peers[0].messages[0]),common(peers[1].messages[0]));
   assert.deepEqual(common(peers[0].messages[0]),common(peers[2].messages[0]));
   const ready=peer(a.id);world.snapshot(ready,true);
   assert.equal(ready.messages[0].type,'ready');
   assert.equal(ready.messages[0].owner.length,sim.size);
   assert.deepEqual(ready.messages[0].ownedUnits,[[unitA.id,artA.id]]);
  });
  await t.test('each publication and direct snapshot sees current state',()=>{
   const first=peer(a.id);world.publish([first]);
   sim.units.get(unitA.id).hp--;
   const second=peer(a.id);world.snapshot(second);
   assert.notDeepEqual(second.messages[0].unitBuffer,first.messages[0].unitBuffer);
   const third=peer(a.id);world.publish([third]);
   assert.deepEqual(third.messages[0],second.messages[0]);
  });
  await t.test('state and initial-snapshot queue limits remain distinct',()=>{
   const slow=peer(a.id,1024*1024+1);world.publish([slow]);assert.equal(slow.readyState,3);
   const initial=peer(a.id,2*1024*1024);world.snapshot(initial,true);assert.equal(initial.readyState,1);assert.equal(initial.messages.length,1);
   const blocked=peer(a.id,8*1024*1024+1);world.snapshot(blocked,true);assert.equal(blocked.readyState,3);
  });
  await t.test('offline rotation retains the oldest-account selection',()=>{
   for(let i=0;i<3;i++)world.accounts.set('offline-'+i,{id:'offline-'+i,team:38,arts:[{...artA,id:'offline-art-'+i}],kills:0,lastOfflineSpawn:i,offlineCursor:0});
   world.rotateOffline();
   const units=[...sim.units.values()].filter(u=>u.accountId?.startsWith('offline-'));
   assert.equal(units.length,1);assert.equal(units[0].accountId,'offline-0');
   assert.equal(world.accounts.get('offline-0').offlineCursor,1);
   world.rotateOffline();
   const rotated=[...sim.units.values()].filter(u=>u.accountId?.startsWith('offline-'));
   assert.equal(rotated.length,1);assert.equal(rotated[0].accountId,'offline-1');
  });
  await t.test('revival sends one artwork and preserves the ownership/event',async()=>{
   await new Promise((resolve,reject)=>{world.server.once('error',reject);world.server.listen(0,'127.0.0.1',resolve)});
   const port=world.server.address().port;
   const response=await fetch('http://127.0.0.1:'+port+'/api/session');const account=await response.json();
   socket=new WebSocket('ws://127.0.0.1:'+port+'/ws',{headers:{Cookie:response.headers.get('set-cookie').split(';')[0]}});
   const messages=[];socket.on('message',bytes=>messages.push(JSON.parse(bytes)));
   await new Promise((resolve,reject)=>{socket.once('open',resolve);socket.once('error',reject)});
   const owner=world.accounts.get(account.accountId);owner.team=37;owner.arts=[{...artA,id:'revival-art'}];
   const spawned=world.spawn(owner,owner.arts[0],city.id);assert(spawned.ok);
   sim.units.get(spawned.id).autoRespawn=true;sim.killUnit(sim.units.get(spawned.id));
   sim.playerRevivePending.get(spawned.id).readyAt=0;
   sim.revivePlayers();
   const revived=[...sim.units.values()].find(u=>u.accountId===owner.id);
   assert(revived&&revived.id!==spawned.id);
   await new Promise(resolve=>setTimeout(resolve,100));
   assert.equal(messages.filter(m=>m.type==='art'&&m.unitId===revived.id).length,1);
   const snapshot=peer(owner.id);world.snapshot(snapshot);
   assert.deepEqual(snapshot.messages[0].ownedUnits,[[revived.id,'revival-art']]);
   assert(snapshot.messages[0].playerRevives.some(r=>r.oldId===spawned.id&&r.newId===revived.id));
  });
  await t.test('season reset recreates multiplayer death/respawn behavior',()=>{
   world.reset('2099-01');const fresh=world.sim();
   assert.notEqual(fresh,sim);assert.equal(a.team,null);assert.deepEqual(a.arts,[]);
   a.team=37;a.arts=[artA];
   const home=fresh.cities.find(c=>c.owner===37&&!c.home);
   const spawned=world.spawn(a,artA,home.id);assert(spawned.ok);
   fresh.units.get(spawned.id).autoRespawn=true;fresh.killUnit(fresh.units.get(spawned.id));
   const grave=fresh.playerRevivePending.get(spawned.id);assert.equal(grave.accountId,a.id);grave.readyAt=0;
   fresh.revivePlayers();assert.equal([...fresh.units.values()].filter(u=>u.accountId===a.id).length,1);
  });
 }finally{
  socket?.terminate();await world.close();fs.rmSync(dir,{recursive:true,force:true});
 }
});
