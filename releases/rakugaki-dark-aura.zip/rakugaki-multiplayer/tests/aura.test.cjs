'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const html=fs.readFileSync(process.env.AURA_HTML||path.join(__dirname,'../index.html'),'utf8');
const mapStart=html.indexOf('<script id="map-source"');
const mapCode=html.slice(html.indexOf('>',mapStart)+1,html.indexOf('</script>',mapStart));
const mapContext={window:{},performance,console,Map,Set};vm.createContext(mapContext);vm.runInContext(mapCode,mapContext);
const colors=mapContext.window.SIM_MAP.teamColors;
const start=html.indexOf(' function drawCapitalAuras('),end=html.indexOf('\n function fit()',start);
assert(start>=0&&end>start,'aura renderer exists');
const strokes=[];
const ctx={save(){},restore(){},setLineDash(){},stroke(path){strokes.push({team:path.team,color:this.strokeStyle,width:this.lineWidth,alpha:this.globalAlpha})}};
const s={zoom:1,width:20000,height:20000,panX:0,panY:0};
const context={s,ctx,COLORS:colors,RGB:colors.map(c=>c?[1,3,5].map(i=>parseInt(c.slice(i,i+2),16)):[0,0,0]),W:1000,TILE:10,ensureCapitalAura(){}};
vm.createContext(context);vm.runInContext(html.slice(start,end),context);
test('capital aura outlines use all 47 prefecture colors at 70% brightness',()=>{
 const cities=Array.from({length:47},(_,i)=>({home:true,owner:i+1,tile:0}));
 const world={cities,auraPaths:new Map(cities.map(c=>[c.owner,{team:c.owner}]))};
 context.drawCapitalAuras(1000,world);
 assert.equal(strokes.length,94);
 for(let team=1;team<=47;team++){
  const outline=strokes.filter(stroke=>stroke.team===team);
  const expected='rgb('+[1,3,5].map(i=>Math.round(parseInt(colors[team].slice(i,i+2),16)*.7)).join(',')+')';
  assert.equal(outline[1].color,expected,'prefecture '+team+' keeps its hue at 70% brightness');
  assert.notEqual(outline[0].color,'rgba(9,17,28,.95)','no nearly black outer rail');
 }
 strokes.length=0;s.zoom=.1;
 context.drawCapitalAuras(1000,world);
 assert.equal(strokes.length,0,'nationwide overview remains uncluttered');
});
