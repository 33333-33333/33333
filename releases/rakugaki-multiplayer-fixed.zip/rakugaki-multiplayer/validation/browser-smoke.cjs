'use strict';
// Local Chromium smoke test. Usage: node browser-smoke.cjs ROOT solo|multi OUTPUT [touch]
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),http=require('node:http');
const assert=require('node:assert/strict'),{spawn}=require('node:child_process'),WebSocket=require('ws');
const root=path.resolve(process.argv[2]),mode=process.argv[3],output=path.resolve(process.argv[4]);
const touch=process.argv[5]==='touch';
const noBackend=process.argv.includes('--no-backend'),twoTabs=process.argv.includes('--two-tabs');
const basePath=process.env.TEST_BASE_PATH||'';
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'rakugaki-browser-'));
const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
let chrome,transport,world,server;
async function main(){try{
 if(mode==='multi'&&!noBackend){
  process.env.DATA_DIR=path.join(dir,'data');process.env.BASE_PATH=basePath;world=require(path.join(root,'server.cjs'));server=world.server;
 }else server=http.createServer((req,res)=>{res.setHeader('Content-Type','text/html; charset=utf-8');res.end(fs.readFileSync(path.join(root,'index.html')))});
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve)});
 chrome=spawn('/usr/bin/chromium',['--headless','--no-sandbox','--disable-dev-shm-usage','--disable-background-networking','--no-first-run','--remote-debugging-port=0','--user-data-dir='+path.join(dir,'profile'),'about:blank'],{stdio:['ignore','ignore','pipe']});
 let diagnostics='';chrome.stderr.on('data',b=>diagnostics+=b);
 let endpoint;
 for(let i=0;i<100;i++){endpoint=diagnostics.match(/DevTools listening on (ws:\/\/[^\s]+)/)?.[1];if(endpoint)break;await wait(100)}
 assert(endpoint,'Chromium debugging endpoint: '+diagnostics.slice(-2000));
 transport=new WebSocket(endpoint);await new Promise((resolve,reject)=>{transport.once('open',resolve);transport.once('error',reject)});
 let nextId=0;const pending=new Map(),exceptions=[];
 transport.on('message',bytes=>{const message=JSON.parse(bytes);if(message.method==='Runtime.exceptionThrown')exceptions.push(message.params.exceptionDetails);const task=pending.get(message.id);if(task){pending.delete(message.id);clearTimeout(task.timeout);if(message.error)task.reject(Error(JSON.stringify(message.error)));else task.resolve(message.result)}});
 function send(method,params={},sessionId){return new Promise((resolve,reject)=>{const id=++nextId,timeout=setTimeout(()=>{pending.delete(id);reject(Error('CDP timeout '+method))},20000);pending.set(id,{resolve,reject,timeout});transport.send(JSON.stringify({id,method,params,sessionId}))})}
 const target=await send('Target.createTarget',{url:'about:blank'});
 const {sessionId}=await send('Target.attachToTarget',{targetId:target.targetId,flatten:true});
 await send('Runtime.enable',{},sessionId);await send('Page.enable',{},sessionId);await send('Network.enable',{},sessionId);
 await send('Network.setBlockedURLs',{urls:['*fonts.googleapis.com*','*fonts.gstatic.com*']},sessionId);
 const observe=`window.__sharedStates=[];window.__localWorkers=0;
 const WorkerClass=window.Worker;window.Worker=class extends WorkerClass{constructor(...args){window.__localWorkers++;super(...args)}};
 const SocketClass=window.WebSocket;window.WebSocket=class extends SocketClass{constructor(...args){super(...args);this.addEventListener('message',event=>{const m=JSON.parse(event.data);if(m.type==='state'){const {ownedUnits,...shared}=m;window.__sharedStates.push({time:m.time,fingerprint:JSON.stringify(shared)});if(window.__sharedStates.length>12)window.__sharedStates.shift()}})}};`;
 await send('Page.addScriptToEvaluateOnNewDocument',{source:observe},sessionId);
 async function viewport(width,height){await send('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:1,mobile:touch},sessionId)}
 await viewport(touch?390:1280,touch?844:900);
 if(touch)await send('Emulation.setTouchEmulationEnabled',{enabled:true,maxTouchPoints:5},sessionId);
 async function evaluate(expression,session=sessionId){const result=await send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true},session);if(result.exceptionDetails)throw Error(JSON.stringify(result.exceptionDetails));return result.result.value}
 async function until(expression,session=sessionId){for(let i=0;i<100;i++){const value=await evaluate(expression,session);if(value)return value;await wait(200)}throw Error('Condition timeout: '+expression+'; health='+JSON.stringify(await evaluate('window.__rakugakiHealth?.()',session)))}
 const origin='http://127.0.0.1:'+server.address().port;
 await send('Page.navigate',{url:origin+basePath+'/'+(mode==='solo'?'?mode=solo':'')},sessionId);
 if(noBackend){
  await until("window.sim?.multiplayerMode && document.getElementById('world-status').dataset.state==='error'");
  await evaluate("document.getElementById('compat-mode').click()");await wait(300);
  const health=await evaluate('window.__rakugakiHealth()');
  assert.equal(health.time,0);assert.equal(health.units,0);assert.equal(health.workerReady,false);
  assert.equal(await evaluate('window.__localWorkers'),0);
  assert.equal(await evaluate('window.sim.engine instanceof window.RakugakiEngine.Simulator'),false);
  assert.equal(await evaluate("document.getElementById('compat-mode').hidden"),true);
  fs.writeFileSync(output,JSON.stringify({noBackend:true,errorVisible:true,localWorldBlocked:true,health,exceptions},null,2));
  console.log('Static-only deployment: error visible, no local world created');return;
 }
 const boot=await until('window.sim?.workerReady && window.__rakugakiHealth()');assert(boot.drawReady);assert(boot.units>1000);
 const multiplayer=await evaluate('!!window.sim.multiplayerMode');assert.equal(multiplayer,mode==='multi');
 const controls=await evaluate("getComputedStyle(document.getElementById('transit-controls')).display");assert.equal(controls==='none',mode==='multi');
 await evaluate("document.getElementById('howto-close').click()");
 if(mode==='solo'){
  assert.equal(await evaluate("document.getElementById('toggle').click();window.sim.playing"),false);
  assert.equal(await evaluate("document.getElementById('toggle').click();window.sim.playing"),true);
  assert.equal(await evaluate("document.querySelector('[data-speed=\"1\"]').click();window.sim.speed"),1);
 }
 await evaluate("document.getElementById('choose-prefecture').click();document.getElementById('prefecture-candidate').value='37';document.getElementById('pref-pick-next').click();document.getElementById('pref-pick-confirm').click()");
 await until("!document.getElementById('player-panel').hidden && document.getElementById('paint-prefecture').value==='37'");
 await evaluate("const preset=document.getElementById('paint-variant');preset.selectedIndex=1;preset.dispatchEvent(new Event('change'));document.getElementById('paint-summon').click()");
 await until("window.sim.playerArt?.size>0 && [...window.sim.engine.units.values()].some(u=>u.kind==='player')");
 await until("document.getElementById('player-panel').hidden && window.sim.pendingPlayerArt===null");
 assert.equal(await evaluate("!!document.getElementById('open-order-menu')"),false);
 assert.equal(await evaluate("!!document.getElementById('form-player-squad')"),false);
 assert.equal(await evaluate("matchMedia('(pointer:coarse)').matches"),touch);
 assert.equal(await evaluate("getComputedStyle(document.getElementById('command-mode')).display!=='none'"),touch);
 // A narrow desktop window must not become a phone; landscape phones keep the toggle.
 await viewport(touch?844:600,touch?390:800);await wait(100);
 assert.equal(await evaluate("getComputedStyle(document.getElementById('command-mode')).display!=='none'"),touch);
 await viewport(touch?390:1280,touch?844:900);await wait(200);
 async function click(point,button='left'){
  if(touch&&button==='left'){
   await send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:point.x,y:point.y,id:1}]},sessionId);
   await send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]},sessionId);
  }else{
   await send('Input.dispatchMouseEvent',{type:'mousePressed',x:point.x,y:point.y,button,buttons:button==='right'?2:1,clickCount:1},sessionId);
   await send('Input.dispatchMouseEvent',{type:'mouseReleased',x:point.x,y:point.y,button,buttons:0,clickCount:1},sessionId);
  }
 }
 async function center(selector){return evaluate(`(()=>{const r=document.querySelector(${JSON.stringify(selector)}).getBoundingClientRect();return{x:r.x+r.width/2,y:r.y+r.height/2}})()`)}
 async function unitPoint(){return evaluate(`(()=>{const s=window.sim,id=[...s.playerArt.keys()].find(id=>s.engine.units.has(id)&&(!s.multiplayerMode||s.multiplayer.unitIds.includes(id))),u=s.engine.units.get(id),p=s.frameUnitPoints?.get(id)||s.unitVisual?.get(id)||{x:(u.tile%window.SIM_MAP.width+.5)*10,y:(Math.floor(u.tile/window.SIM_MAP.width)+.5)*10},r=document.getElementById('map').getBoundingClientRect();return{x:r.x+p.x*s.zoom+s.panX,y:r.y+p.y*s.zoom+s.panY,id}})()`)}
 if(touch){await click(await center('#command-mode'));await until('window.sim.commandMode');}
 const point=await unitPoint();
 await click(point,touch?'left':'right');
 await until("!document.getElementById('radial-order-menu').hidden && window.sim.selectedPlayerIds.size>0");
 assert.equal(await evaluate("document.querySelector('#radial-order-menu [data-action=wait]').disabled"),false);
 if(!touch){
  // Cancel, then prove right-drag still opens the independent radial menu.
  await click(await center('#radial-order-menu [data-action=cancel]'));
  const p=await unitPoint();
  await send('Input.dispatchMouseEvent',{type:'mousePressed',x:p.x-10,y:p.y-10,button:'right',buttons:2,clickCount:1},sessionId);
  await send('Input.dispatchMouseEvent',{type:'mouseMoved',x:p.x+10,y:p.y+10,button:'right',buttons:2},sessionId);
  await send('Input.dispatchMouseEvent',{type:'mouseReleased',x:p.x+10,y:p.y+10,button:'right',buttons:0,clickCount:1},sessionId);
  await until("!document.getElementById('radial-order-menu').hidden && window.sim.selectedPlayerIds.size>0");
 }
 const screenshot=await send('Page.captureScreenshot',{format:'png'},sessionId);
 fs.writeFileSync(output.replace(/\.json$/,'.png'),Buffer.from(screenshot.data,'base64'));
 await click(await center('#radial-order-menu [data-action=wait]'));
 await until("window.sim.radialMoveMode==='wait'");
 await click(await unitPoint());
 await until("document.getElementById('command-status').textContent.includes('移動指令を出しました')");
 if(touch){
  await click(await center('#command-mode'));await until('window.sim.commandMode===false');
  await click(await unitPoint());await wait(100);
  assert.equal(await evaluate("document.getElementById('radial-order-menu').hidden"),true);
  await viewport(844,390);await wait(200);
  await click(await center('#command-mode'));await until('window.sim.commandMode');
  await click(await unitPoint());
  await until("!document.getElementById('radial-order-menu').hidden && window.sim.selectedPlayerIds.size>0");
  await click(await center('#radial-order-menu [data-action=cancel]'));
  await click(await center('#command-mode'));await until('window.sim.commandMode===false');
  await viewport(390,844);
 }
 // Reload checks the saved source as well as the current DOM.
 await send('Page.reload',{},sessionId);await until('window.sim?.workerReady');
 assert.equal(await evaluate("!!document.getElementById('open-order-menu')"),false);
 assert.equal(await evaluate("getComputedStyle(document.getElementById('command-mode')).display!=='none'"),touch);
 let aura=null;
 if(process.argv.includes('--aura')){
  const target=await evaluate(`(()=>{
   document.getElementById('howto-close').click();
   const s=window.sim,home=s.engine.cities.find(c=>c.home&&c.owner===13),width=window.SIM_MAP.width;
   s.zoom=1.5;s.panX=s.width/2-(home.tile%width+.5)*10*s.zoom;s.panY=s.height/2-(Math.floor(home.tile/width)+.5)*10*s.zoom;
   window.__auraPaint=[];
   const original=CanvasRenderingContext2D.prototype.stroke;
   CanvasRenderingContext2D.prototype.stroke=function(path){
    if(this.canvas.id==='map'){
     const owner=[...(window.sim.engine.auraPaths||[])].find(([,p])=>p===path)?.[0];
     if(owner&&window.__auraPaint.length<200)window.__auraPaint.push({team:owner,color:this.strokeStyle});
    }
    return original.apply(this,arguments);
   };
   return {team:home.owner,city:home.name,color:'#'+[1,3,5].map(i=>Math.round(parseInt(window.SIM_MAP.teamColors[home.owner].slice(i,i+2),16)*.7).toString(16).padStart(2,'0')).join('')};
  })()`);
  await until(`window.__auraPaint?.some(p=>p.team===${target.team}&&p.color===${JSON.stringify(target.color)})`);
  aura={...target,strokes:await evaluate(`window.__auraPaint.filter(p=>p.team===${target.team}).slice(0,2)`)};
  assert.equal(aura.strokes[1].color,target.color);
  assert(aura.strokes[0].color.startsWith('rgba(255, 250, 231,'));
  const shot=await send('Page.captureScreenshot',{format:'png'},sessionId);
  fs.writeFileSync(output.replace(/\.json$/,'.aura.png'),Buffer.from(shot.data,'base64'));
 }
 let sharedTabs=null;
 if(twoTabs){
  assert.equal(mode,'multi');
  const nextTarget=await send('Target.createTarget',{url:'about:blank'});
  const secondSession=(await send('Target.attachToTarget',{targetId:nextTarget.targetId,flatten:true})).sessionId;
  await send('Runtime.enable',{},secondSession);await send('Page.enable',{},secondSession);await send('Network.enable',{},secondSession);
  await send('Network.setBlockedURLs',{urls:['*fonts.googleapis.com*','*fonts.gstatic.com*']},secondSession);
  await send('Page.addScriptToEvaluateOnNewDocument',{source:observe},secondSession);
  await send('Page.navigate',{url:origin+basePath+'/index.html'},secondSession);
  await until('window.sim?.workerReady && window.sim.multiplayer?.unitIds?.length>0',secondSession);
  const firstHealth=await evaluate('window.__rakugakiHealth()'),secondHealth=await evaluate('window.__rakugakiHealth()',secondSession);
  assert(firstHealth.worldId);assert.equal(firstHealth.worldId,secondHealth.worldId);
  const unitId=await evaluate('window.sim.multiplayer.unitIds[0]');
  await until(`window.sim.engine.units.has(${unitId})&&window.sim.playerArt.has(${unitId})`,secondSession);
  await until('window.__sharedStates.length>=2');await until('window.__sharedStates.length>=2',secondSession);
  const a=await evaluate('window.__sharedStates'),b=await evaluate('window.__sharedStates',secondSession);
  assert(a.some(first=>b.some(second=>first.fingerprint===second.fingerprint)),'tabs receive an identical public snapshot');
  await evaluate("document.getElementById('compat-mode').click();window.sim.worker.onmessage({data:{type:'error',error:'test error'}})");await wait(100);
  assert.equal(await evaluate('window.sim.engine instanceof window.RakugakiEngine.Simulator'),false);
  assert.equal(await evaluate('window.__localWorkers'),0);assert.equal(await evaluate('window.__localWorkers',secondSession),0);
  await evaluate('window.sim.worker.socket.close()');
  await until("!window.sim.workerReady");
  await until('window.sim.workerReady');
  assert.equal((await evaluate('window.__rakugakiHealth()')).worldId,firstHealth.worldId);
  assert.equal((await evaluate('window.__rakugakiHealth()',secondSession)).worldId,firstHealth.worldId);
  sharedTabs={worldId:firstHealth.worldId,identicalPublicSnapshot:true,spawnedUnitVisibleInBothTabs:true,noLocalFallback:true,reconnectedSameWorld:true};
 }
 const result={mode,touch,basePath,sharedTabs,workerReady:true,drawReady:true,controlsHidden:controls==='none',prefectureSelection:true,summon:true,commandMenuButtonRemoved:true,commandToggleTouchOnly:true,resizePolicy:true,radialSelection:true,rightDrag:touch?null:true,radialWaitOrder:true,toggleOff:touch?true:null,landscapeRadial:touch?true:null,reloadPolicy:true,aura,health:await evaluate('window.__rakugakiHealth()'),exceptions};
 assert.equal(exceptions.length,0,'Browser uncaught exceptions');
 fs.writeFileSync(output,JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
 }finally{
  transport?.close();if(chrome){chrome.kill('SIGTERM');await new Promise(resolve=>{if(chrome.exitCode!==null)resolve();else chrome.once('exit',resolve)})}
  if(world)await world.close();else if(server)await new Promise(resolve=>server.close(resolve));fs.rmSync(dir,{recursive:true,force:true});
 }}
main().catch(error=>{console.error(error);process.exitCode=1});
