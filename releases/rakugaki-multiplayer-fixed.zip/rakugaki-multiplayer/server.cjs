'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),crypto=require('node:crypto'),vm=require('node:vm'),v8=require('node:v8');
const {WebSocketServer,WebSocket}=require('ws');
const {PNG}=require('pngjs');
const ROOT=__dirname,DATA=process.env.DATA_DIR||path.join(ROOT,'data'),PORT=Number(process.env.PORT||3000);
const BASE_PATH=(process.env.BASE_PATH||'').replace(/\/+$/,'');
if(BASE_PATH&&(!BASE_PATH.startsWith('/')||BASE_PATH.startsWith('//')||/[?#]/.test(BASE_PATH)||BASE_PATH.includes('..')))throw Error('Invalid BASE_PATH');
function routeOf(url){const pathname=new URL(url,'http://localhost').pathname;return BASE_PATH&&(pathname===BASE_PATH||pathname.startsWith(BASE_PATH+'/'))?pathname.slice(BASE_PATH.length)||'/':pathname}
const SPEED=Math.max(1,Math.min(120,Number(process.env.SIM_SPEED||1)));
const WORLD_ID=crypto.randomUUID(),BUILD_ID='2026-10-28-shared-1';
const html=fs.readFileSync(path.join(ROOT,'index.html'),'utf8');
function source(id){const pos=html.indexOf('<script id="'+id+'"');if(pos<0)throw Error('Source missing '+id);const a=html.indexOf('>',pos)+1;return html.slice(a,html.indexOf('</script>',a))}
const context={window:{},performance,console,Map,Set};vm.createContext(context);
vm.runInContext(source('map-source'),context);vm.runInContext(source('engine-source'),context);
const MAP=context.window.SIM_MAP,{Simulator}=context.window.RakugakiEngine;
const seasonOf=(when=Date.now())=>{const d=new Date(when+9*3600000);return d.getUTCFullYear()+'-'+String(d.getUTCMonth()+1).padStart(2,'0')};
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
fs.mkdirSync(DATA,{recursive:true});
const STATE=path.join(DATA,'world.bin'),ACCOUNTS=path.join(DATA,'accounts.json'),BACKUP=path.join(DATA,'backups');
fs.mkdirSync(BACKUP,{recursive:true});
const LOCK=path.join(DATA,'server.lock');
let lockFd=null;
function acquireWorldLock(){
 if(lockFd!==null)return;
 let fd;
 try{
  fd=fs.openSync(LOCK,'wx',0o600);
  fs.writeFileSync(fd,JSON.stringify({pid:process.pid,worldId:WORLD_ID}));
  lockFd=fd;
 }catch(error){
  if(fd!==undefined){fs.closeSync(fd);fs.unlinkSync(LOCK)}
  if(error.code==='EEXIST')throw Object.assign(Error('DATA_DIR is already locked: '+path.resolve(LOCK)+'. Run only one server. Remove a stale lock only after confirming the old server has stopped.'),{code:'WORLD_ALREADY_RUNNING'});
  throw error;
 }
}
function releaseWorldLock(){
 if(lockFd===null)return;
 fs.closeSync(lockFd);lockFd=null;
 try{if(JSON.parse(fs.readFileSync(LOCK,'utf8')).worldId===WORLD_ID)fs.unlinkSync(LOCK)}catch{}
}
process.once('exit',releaseWorldLock);
const accounts=new Map(),tokens=new Map(),connections=new Set();
let season=seasonOf(),sim=createSimulator(),lastBackup='',lastSaved=Date.now(),lastRotation=Date.now();
let recentRevives=[];
function online(a,now=Date.now()){
 for(const w of connections.keys())if(w.accountId===a.id&&w.readyState===WebSocket.OPEN&&now-w.lastSeen<30000)return true;
 return false;
}
function myUnits(a){return [...sim.units.values()].filter(u=>u.accountId===a.id)}
function createSimulator(){
 const engine=new Simulator(MAP,{seed:20261023});
 engine.killUnit=function(unit,...args){
  Simulator.prototype.killUnit.call(this,unit,...args);
  for(const map of [this.playerGraveyard,this.playerRevivePending]){
   const grave=map.get(unit.id);
   if(grave)Object.assign(grave,{accountId:unit.accountId,artId:unit.artId});
  }
 };
 engine.revivePlayers=function(){
  for(const [id,grave] of this.playerRevivePending){
   if(this.time<grave.readyAt)continue;
   const account=accounts.get(grave.accountId),art=account?.arts.find(p=>p.id===grave.artId);
   if(!account||!art){this.playerRevivePending.delete(id);this.playerGraveyard.delete(id);continue}
   const city=this.cities.find(c=>c.owner===account.team&&c.capturer===null);
   const result=city&&spawn(account,art,city.id,!online(account));
   if(result?.ok){
    const unit=this.units.get(result.id);
    unit.autoRespawn=true;
    this.playerReviveEvents.push({oldId:id,newId:unit.id,tile:unit.tile,team:account.team,role:art.role});
   }else grave.readyAt=this.time+30;
  }
 };
 engine.cpuMax=function(team){
  let count=0;
  for(const account of accounts.values())if(account.team===team&&account.arts.length&&!online(account))count++;
  return Simulator.prototype.cpuMax.call(this,team)+Math.floor(Math.sqrt(count));
 };
 return engine;
}
const capacity=a=>Math.min(24,6+Math.floor((a.kills||0)/25));
function atomic(file,b){fs.writeFileSync(file+'.tmp',b);fs.renameSync(file+'.tmp',file)}
const stateFields=['time','owner','occupied','tileCounts','troopCounts','cityCounts','cities','units','pending','playerRevivePending','playerGraveyard','playerReviveEvents','projectiles','effects','events','eventsVersion','mapVersion','nextId','nextEffectId','counters','homes','squads','playerSquads','nextSquadId','nextPlayerSquadId','squadHistory','territoryHistory','seed'];
let saveTimer=null;
function schedulePersist(){if(!saveTimer)saveTimer=setTimeout(()=>{saveTimer=null;try{persist()}catch(e){console.error('Save failed',e.message)}},1000).unref()}
function persist(){if(saveTimer){clearTimeout(saveTimer);saveTimer=null}const state={};for(const k of stateFields)if(sim[k]!==undefined)state[k]=sim[k];atomic(STATE,v8.serialize({season,state}));atomic(ACCOUNTS,JSON.stringify({season,accounts:[...accounts.values()]}))}
function restore(){try{
 const info=JSON.parse(fs.readFileSync(ACCOUNTS,'utf8'));if(info.season===season)for(const a of info.accounts){accounts.set(a.id,a);if(a.tokenHash)tokens.set(a.tokenHash,a.id)}
 const saved=v8.deserialize(fs.readFileSync(STATE));if(saved.season!==season)return;
 for(const k of stateFields)if(saved.state[k]!==undefined)sim[k]=saved.state[k];
 sim.cityAt=new Map(sim.cities.map(c=>[c.tile,c]));sim.cityBuckets=new Map();for(const c of sim.cities){const key=Math.floor(Math.floor(c.tile/sim.w)/16)*10000+Math.floor(c.tile%sim.w/16);if(!sim.cityBuckets.has(key))sim.cityBuckets.set(key,[]);sim.cityBuckets.get(key).push(c)}sim.homes=new Map(sim.cities.filter(c=>c.home).map(c=>[c.tile,c]));sim.computeConnectivity();sim.refreshAura();sim.ownedTiles=Array.from({length:sim.teamCount+1},()=>[]);
 for(const t of sim.playableTiles)if(sim.owner[t]>0)sim.ownedTiles[sim.owner[t]].push(t);
 sim.combatBuckets=new Map();sim.combatBucketOf=new Map();sim.zones=new Map();sim.zoneRefreshedAt=new Map();sim.claimFlow=new Map();sim.lastZoneRefresh=-Infinity;sim.lastFlowRefresh=-Infinity;
 console.log('Restored world:',sim.time);
}catch(e){if(e.code!=='ENOENT')console.warn('Restore failed:',e.message)}}
restore();
function backup(now=Date.now()){const day=new Date(now+9*3600000).toISOString().slice(0,10);if(day===lastBackup)return;
 persist();const dest=path.join(BACKUP,day);fs.mkdirSync(dest,{recursive:true});fs.copyFileSync(STATE,path.join(dest,'world.bin'));fs.copyFileSync(ACCOUNTS,path.join(dest,'accounts.json'));
 for(const name of fs.readdirSync(BACKUP).sort().slice(0,-3))fs.rmSync(path.join(BACKUP,name),{recursive:true,force:true});lastBackup=day}
function send(w,message,type=message.type){
 if(w.readyState!==WebSocket.OPEN)return;
 const limit=type==='state'?1024*1024:8*1024*1024;
 if(w.bufferedAmount>limit){w.terminate();return}
 w.send(typeof message==='string'?message:JSON.stringify(message));
}
function broadcast(message){
 const json=JSON.stringify(message);
 for(const w of connections)send(w,json,message.type);
}
function info(a){return{type:'session',worldId:WORLD_ID,accountId:a.id,team:a.team,season,kills:a.kills,artLimit:capacity(a),registered:a.arts.length,unitIds:myUnits(a).map(u=>u.id),paintings:a.arts.map(p=>({id:p.id,image:p.image,role:p.role})),onlineLimit:10,offlineLimit:1}}
function auth(req,res){const token=(req.headers.cookie||'').split(';').map(s=>s.trim()).find(s=>s.startsWith('rakugaki_sid='))?.slice(13);
 const id=token&&tokens.get(sha(token));if(id&&accounts.has(id))return accounts.get(id);if(!res)return null;
 if(accounts.size>=10000||!allow('register:'+req.socket.remoteAddress,10,60000)){res.statusCode=429;return null}
 const secret=crypto.randomBytes(32).toString('base64url');
 const a={id:crypto.randomUUID(),tokenHash:sha(secret),team:null,kills:0,arts:[],cooldown:0,lastUsed:null,lastOfflineSpawn:0,offlineCursor:0};
 accounts.set(a.id,a);tokens.set(a.tokenHash,a.id);
 res.setHeader('Set-Cookie','rakugaki_sid='+secret+'; HttpOnly; SameSite=Lax; Path=/; Max-Age=31536000'+(req.socket.encrypted||process.env.COOKIE_SECURE==='1'?'; Secure':''));
 schedulePersist();return a}
function removeUnit(u){if(!sim.units.has(u.id))return;
 if(u.playerSquadId!=null)sim.dissolvePlayerSquad(u.playerSquadId);
 if(u.squadId!=null)sim.squads.get(u.squadId)?.members.delete(u.id);
 sim.units.delete(u.id);if(!u.atSea&&sim.occupied[u.tile]===u.id)sim.occupied[u.tile]=-1;
 if(u.atSea)sim.seaMoving?.delete(u.id);sim.troopCounts[u.team]--;
}
function cancelRevives(accountId,artId){
 for(const map of [sim.playerRevivePending,sim.playerGraveyard]){
  for(const [id,grave] of map)if(grave.accountId===accountId&&grave.artId===artId)map.delete(id);
 }
}
function replaceCpu(team,places){const cpu=places.map(t=>sim.getUnitAt(t)).find(u=>u?.kind==='cpu'&&u.team===team)||
 [...sim.units.values()].find(u=>u.kind==='cpu'&&u.team===team&&!u.atSea);
 if(!cpu)return false;removeUnit(cpu);return true}
function spawn(a,art,cityId,offline=false){
 const city=sim.cityById(String(cityId));if(!city||city.owner!==a.team||city.capturer!==null)return{ok:false,error:'この都市からは出撃できません'};
 const units=myUnits(a);
 if(units.some(u=>u.artId===art.id))return{ok:false,error:'同じ絵は同時に1体までです'};
 if(units.length>=(offline?1:10))return{ok:false,error:'出撃上限に達しています'};
 const places=[city.tile,...sim.spawnPositions(city,a.team)];
 const cap=sim.cpuMax(a.team)+(sim.cities.some(c=>c.owner===a.team&&!c.home)?0:sim.cfg.lastStandBonus);
 if(sim.troopCounts[a.team]>=cap&&!replaceCpu(a.team,places))return{ok:false,error:'この県の部隊枠が満員です'};
 let unit=null;for(const t of places)if(sim.owner[t]===a.team&&sim.canEnter(t,a.team)){unit=sim.addUnit(a.team,t,'player',art.role);if(unit)break}
 if(!unit)return{ok:false,error:'都市周辺に空きがありません'};
 cancelRevives(a.id,art.id);
 Object.assign(unit,{accountId:a.id,artId:art.id,offlineAI:offline,accountKillsRecorded:0});
 a.lastUsed=art.id;
 broadcast({type:'art',unitId:unit.id,image:art.image,pixels:art.pixels||24,accountId:a.id});
 return{ok:true,id:unit.id,artId:art.id,city:city.name,team:a.team,tile:unit.tile}}
function offlineAccount(a,now=Date.now()){if(!a||online(a,now))return;const units=myUnits(a),keep=units.find(u=>u.artId===a.lastUsed)||units[0];
 for(const u of units)if(u!==keep)removeUnit(u);
 if(keep){if(keep.playerSquadId!=null)sim.dissolvePlayerSquad(keep.playerSquadId);keep.order=null;keep.holdPosition=false;keep.offlineAI=true}}
function rotateOffline(now=Date.now()){
 const groups=Array.from({length:48},()=>[]);
 for(const account of accounts.values()){
  if(Number.isInteger(account.team)&&groups[account.team]&&account.arts.length&&!online(account,now))groups[account.team].push(account);
 }
 for(let team=1;team<=47;team++){
  const list=groups[team].sort((a,b)=>(a.lastOfflineSpawn||0)-(b.lastOfflineSpawn||0));
  const seats=Math.min(list.length,Math.floor(Math.sqrt(list.length)));
  if(list.length>seats)for(const u of list.flatMap(myUnits))removeUnit(u);
  let present=list.reduce((n,a)=>n+myUnits(a).length,0);
  for(const a of list){if(present>=seats)break;if(myUnits(a).length)continue;
   const art=a.arts[a.offlineCursor%a.arts.length];
   const city=sim.cities.find(c=>c.owner===team&&c.home&&c.capturer===null)||sim.cities.find(c=>c.owner===team&&c.capturer===null);
   if(art&&city){const r=spawn(a,art,city.id,true);if(r.ok){present++;a.offlineCursor++;a.lastOfflineSpawn=now}}
  }
 }lastRotation=now}
function reset(newSeason=seasonOf()){if(newSeason===season)return;season=newSeason;sim=createSimulator();recentRevives=[];
 for(const a of accounts.values()){a.team=null;a.arts=[];a.kills=0;a.cooldown=0;a.offlineCursor=0;a.lastUsed=null}
 broadcast({type:'seasonReset',season});for(const w of connections.keys()){send(w,info(accounts.get(w.accountId)));snapshot(w,true)}persist()}
function snapshotFrame(full=false){
 const units=[...sim.units.values()],buffer=[],owned=new Map();
 for(const unit of units)if(unit.accountId){
  if(!owned.has(unit.accountId))owned.set(unit.accountId,[]);
  owned.get(unit.accountId).push([unit.id,unit.artId]);
 }
 for(const u of units)buffer.push(u.id,u.team,u.kind==='cpu'?0:1,u.role==='artillery'?1:u.role==='heavy'?2:0,u.art,u.tile,u.hp,u.kills,u.captures,
 u.moveTo,u.moveProgress,u.attackCooldown,u.enteredAt,u.isolatedFor,u.isolated?1:0,u.nextDecisionAt,u.atSea?1:0,u.waitingSea?1:0,u.lastCombatAt??-1,u.cpuWaitUntil||0,u.cpuMode==='wait'?1:0);
 const msg={type:full?'ready':'state',worldId:WORLD_ID,time:sim.time,mapVersion:sim.mapVersion,delta:full?[]:sim.dirtyTiles.map(t=>[t,sim.owner[t]]),
 cities:sim.cities.map(c=>[c.id,c.owner,c.progress,c.capturer,c.home?1:0]),unitBuffer:buffer,
 unitOrders:units.filter(u=>u.kind==='player'&&(u.order!=null||u.holdPosition)).map(u=>[u.id,u.order,u.orderMode||'free',u.holdPosition?1:0]),
 squadLeaders:[...[...sim.squads.values()].map(g=>[g.captainId,g.phase,g.members.size,'cpu']),...[...sim.playerSquads.values()].map(g=>[g.captainId,'player',g.members.size,'player'])],
 squadGroups:[...[...sim.squads.values()].map(g=>[g.captainId,[...g.members],'cpu']),...[...sim.playerSquads.values()].map(g=>[g.captainId,[...g.members],'player'])],
 playerRevives:recentRevives,
 events:sim.events,eventsVersion:sim.eventsVersion,effects:sim.effects.slice(-240),activeShells:sim.projectiles.map(p=>p.shellId),
 stats:sim.stats(),perf:{avgMs:0,maxMs:0,p95Ms:0,ticks:0,effectiveSpeed:SPEED,backlogSeconds:0,droppedGameSeconds:0,bytes:0}};
 if(full)msg.owner=Array.from(sim.owner);
 return {message:msg,owned};
}
function snapshot(w,full=false){
 const {message,owned}=snapshotFrame(full);
 message.ownedUnits=owned.get(w.accountId)||[];
 send(w,message);
}
function publish(peers){
 const list=[...peers];
 if(list.length===1)return snapshot(list[0]);
 if(!list.length)return;
 const {message,owned}=snapshotFrame();
 // Encode the common object once; append the per-account property at its boundary.
 const prefix=JSON.stringify(message).slice(0,-1);
 for(const w of list){
  send(w,prefix+',"ownedUnits":'+JSON.stringify(owned.get(w.accountId)||[])+'}',message.type);
 }
}
const buckets=new Map();
function allow(key,limit,period){const now=Date.now();let b=buckets.get(key);if(!b||now-b.at>=period){if(buckets.size>=20000){for(const [k,v] of buckets)if(now-v.at>=60000)buckets.delete(k);if(buckets.size>=20000)return false}b={at:now,n:0};buckets.set(key,b)}return ++b.n<=limit}
function validMessage(m){
 if(!m||Array.isArray(m)||typeof m.type!=='string')return false;
 switch(m.type){
  case 'init':case 'snapshot':return true;
  case 'selectTeam':return Number.isSafeInteger(m.team);
  case 'summon':return Number.isSafeInteger(m.team)&&Number.isSafeInteger(m.pixels)&&typeof m.cityId==='string';
  case 'deleteArt':return typeof m.artId==='string';
  case 'playerOrders':return Number.isSafeInteger(m.tile)&&Array.isArray(m.ids)&&m.ids.length<=10&&m.ids.every(Number.isSafeInteger)&&['free','wait'].includes(m.mode);
  case 'formPlayerSquad':return Number.isSafeInteger(m.leaderId);
  case 'setPlayerAutoRespawn':return Number.isSafeInteger(m.id)&&typeof m.enabled==='boolean';
  default:return false;
 }
}
function normalizeImage(image){if(typeof image!=='string'||image.length>120000||!/^data:image\/png;base64,[A-Za-z0-9+/]+={0,2}$/.test(image))throw Error('image');const b=Buffer.from(image.slice(22),'base64');if(b.length<33||b.subarray(0,8).toString('hex')!=='89504e470d0a1a0a'||b.toString('ascii',12,16)!=='IHDR')throw Error('png');const w=b.readUInt32BE(16),h=b.readUInt32BE(20);if(![8,16,24].includes(w)||h!==w)throw Error('dimensions');let offset=8;while(offset+12<=b.length){const n=b.readUInt32BE(offset),t=b.toString('ascii',offset+4,offset+8);if(n>b.length-offset-12||t==='acTL')throw Error('chunks');offset+=12+n}if(offset!==b.length)throw Error('chunks');const png=PNG.sync.read(b,{checkCRC:true});return {image:'data:image/png;base64,'+PNG.sync.write(png).toString('base64'),pixels:w}}
function handle(w,bytes){let m;try{if(bytes.length>300000)return;m=JSON.parse(bytes.toString())}catch{return}
 const a=accounts.get(w.accountId);if(!a||!validMessage(m))return send(w,{type:'error',error:'Invalid message'});if(!allow('messages:'+a.id,40,1000))return; w.lastSeen=Date.now();
 if(m.type==='init'||m.type==='snapshot'){if(Date.now()-(w.lastSnapshot||0)<3000)return;w.lastSnapshot=Date.now();send(w,info(a));snapshot(w,true);for(const u of sim.units.values())if(u.artId){
  const art=accounts.get(u.accountId)?.arts.find(p=>p.id===u.artId);if(art)send(w,{type:'art',unitId:u.id,image:art.image,pixels:art.pixels||24,accountId:u.accountId})
 }return}
 if(m.type==='selectTeam'){const team=m.team,ok=team>=1&&team<=47&&(!a.team||a.team===team);
  if(ok&&a.team!==team){a.team=team;schedulePersist()}send(w,{type:'teamResult',ok,team,error:ok?'':'所属県は次の月まで変更できません'});send(w,info(a));return}
 if(m.type==='summon'){
  if(!a.team||m.team!==a.team)return send(w,{type:'summonResult',ok:false,error:'所属県が異なります'});
  const left=a.cooldown-Date.now();if(left>0)return send(w,{type:'summonResult',ok:false,error:'クールダウン中',cooldownMs:left});
  if(!['melee','heavy','artillery'].includes(m.role))return send(w,{type:'summonResult',ok:false,error:'Invalid role'});let normalized;try{normalized=normalizeImage(m.image)}catch{return send(w,{type:'summonResult',ok:false,error:'Invalid PNG dimensions or data'})}m.image=normalized.image;m.pixels=normalized.pixels;
  const key=sha(m.image+m.role);let art=a.arts.find(p=>p.hash===key);const fresh=!art;
  if(fresh){if(a.arts.length>=capacity(a))return send(w,{type:'summonResult',ok:false,error:'保有枠がいっぱいです'});
   art={id:crypto.randomUUID(),hash:key,image:m.image,role:m.role,pixels:m.pixels}}
  const result=spawn(a,art,m.cityId);if(result.ok){if(fresh)a.arts.push(art);a.cooldown=Date.now()+10000;result.cooldownMs=10000;send(w,info(a));schedulePersist()}
  send(w,{type:'summonResult',...result});return}
 if(m.type==='deleteArt'){const art=a.arts.find(p=>p.id===m.artId);if(!art)return send(w,{type:'deleteArtResult',ok:false,error:'絵が見つかりません'});
  for(const u of myUnits(a))if(u.artId===art.id)removeUnit(u);cancelRevives(a.id,art.id);
  a.arts=a.arts.filter(p=>p.id!==art.id);send(w,{type:'deleteArtResult',ok:true,artId:art.id});send(w,info(a));schedulePersist();return}
 if(m.type==='playerOrders'){const ids=m.ids.filter(id=>sim.units.get(id)?.accountId===a.id);
  const target=m.tile,valid=target>=0&&target<sim.size&&sim.isPassable(target);
  const n=valid?sim.commandPlayerUnits(ids,a.team,target,m.mode):0;send(w,{type:'ordersResult',ok:n>0,count:n,target,error:n?'':'操作できるユニットがありません'});return}
 if(m.type==='formPlayerSquad'){const leader=sim.units.get(m.leaderId),result=leader?.accountId===a.id?sim.formPlayerSquad(leader.id,a.team,8):{ok:false,error:'操作権がありません'};send(w,{type:'playerSquadResult',...result});return}
 if(m.type==='setPlayerAutoRespawn'){const u=sim.units.get(m.id),ok=!!u&&u.accountId===a.id&&sim.setPlayerAutoRespawn(u.id,m.enabled);send(w,{type:'playerAutoRespawnResult',id:m.id,ok});return}
}
const server=http.createServer((req,res)=>{let route;try{route=routeOf(req.url)}catch{res.writeHead(400);res.end();return}
 if(route==='/START_HERE.html'){res.setHeader('Content-Type','text/html; charset=utf-8');res.setHeader('Cache-Control','no-store');res.end(fs.readFileSync(path.join(ROOT,'START_HERE.html'),'utf8'));return}
 if(route==='/api/session'){const a=auth(req,res);if(!a){res.end('Registration limit');return}res.setHeader('Cache-Control','no-store');res.setHeader('Content-Type','application/json');res.end(JSON.stringify(info(a)));return}
 if(route==='/api/health'){res.setHeader('Content-Type','application/json');res.end(JSON.stringify({ok:true,mode:'multiplayer',worldId:WORLD_ID,basePath:BASE_PATH||'/',build:BUILD_ID,time:sim.time,season,accounts:accounts.size,units:sim.units.size}));return}
 if(route==='/'||route==='/index.html'){res.setHeader('Content-Type','text/html; charset=utf-8');res.setHeader('Cache-Control','no-store');res.end(fs.readFileSync(path.join(ROOT,'index.html'),'utf8'));return}
 res.writeHead(404);res.end('Not found')});
const listen=server.listen;
server.listen=function(...args){
 acquireWorldLock();
 try{return listen.apply(this,args)}catch(error){if(!this.listening)releaseWorldLock();throw error}
};
server.on('close',releaseWorldLock);
const wss=new WebSocketServer({noServer:true,maxPayload:300000});
server.on('upgrade',(req,socket,head)=>{
 let route;try{route=routeOf(req.url)}catch{socket.destroy();return}if(route!=='/ws'){socket.destroy();return}
 const origin=req.headers.origin;if(origin){let ok=false;try{ok=new URL(origin).host===req.headers.host}catch{}if(!ok){socket.destroy();return}}
 const a=auth(req,null);if(!a){socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');socket.destroy();return}
 if([...connections.keys()].filter(w=>w.accountId===a.id).length>=3||connections.size>=500){socket.destroy();return}
 wss.handleUpgrade(req,socket,head,w=>{w.accountId=a.id;w.lastSeen=Date.now();connections.add(w);
  w.on('message',bytes=>{try{handle(w,bytes)}catch{send(w,{type:'error',error:'Message rejected'})}});w.on('pong',()=>w.lastSeen=Date.now());w.on('close',()=>{connections.delete(w);setTimeout(()=>offlineAccount(a),31000).unref()});w.on('error',e=>console.warn(e.message));send(w,info(a))})});
let accumulator=0,last=performance.now(),lastPublish=0;
const loop=setInterval(()=>{try{
 const now=performance.now(),elapsed=Math.min(.3,Math.max(0,(now-last)/1000));last=now;reset();accumulator=Math.min(SPEED*2,accumulator+elapsed*SPEED);
 let count=0,start=performance.now();while(accumulator>=1&&count<32){sim.tick(1);accumulator--;count++;if(performance.now()-start>14)break}
 recentRevives.push(...sim.playerReviveEvents.splice(0));
 for(const u of sim.units.values())if(u.accountId){const a=accounts.get(u.accountId),k=u.kills||0,prev=u.accountKillsRecorded||0;if(a&&k>prev)a.kills+=k-prev;u.accountKillsRecorded=k}
 if(now-lastPublish>700){publish(connections.keys());sim.dirtyTiles=[];recentRevives=[];lastPublish=now}
 const wall=Date.now();if(wall-lastRotation>600000)rotateOffline(wall);if(wall-lastSaved>60000){persist();lastSaved=wall}backup(wall);
}catch(e){console.error('Game loop error',e.stack)}},20);
const ping=setInterval(()=>{for(const w of connections.keys())if(w.readyState===WebSocket.OPEN)try{if(Date.now()-w.lastSeen>30000){w.terminate();continue}w.ping()}catch{}},10000);
let stopping=false;
async function close(){if(stopping)return;stopping=true;clearInterval(loop);clearInterval(ping);persist();for(const w of connections.keys())w.terminate();await new Promise(ok=>server.close(ok))}
if(require.main===module)server.listen(PORT,process.env.HOST||'0.0.0.0',()=>console.log('Rakugaki multiplayer:',PORT,season));
for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>close().then(()=>process.exit(0)));
module.exports={publish,snapshot,schedulePersist,normalizeImage,handle,server,sim:()=>sim,accounts,capacity,spawn,offlineAccount,rotateOffline,backup,reset,persist,close,seasonOf};
