'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),{spawnSync}=require('node:child_process');
const WebSocket=require('ws'),{PNG}=require('pngjs');
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'rakugaki-shared-'));
process.env.DATA_DIR=dir;process.env.BASE_PATH='/~333/japan';
const world=require('../server.cjs');
function next(socket,predicate){return new Promise((resolve,reject)=>{
 const timer=setTimeout(()=>{socket.off('message',handler);reject(Error('message timeout'))},12000);
 function handler(bytes){const message=JSON.parse(bytes);if(predicate(message)){clearTimeout(timer);socket.off('message',handler);resolve(message)}}
 socket.on('message',handler);
})}
test('multiplayer server shares one world and guards deployment mistakes',async t=>{
 const sockets=[];
 try{
  await new Promise(resolve=>world.server.listen(0,'127.0.0.1',resolve));
  const base='http://127.0.0.1:'+world.server.address().port+'/~333/japan';
  const health=await (await fetch(base+'/api/health')).json();
  await t.test('prefixed endpoints identify the shared server',()=>{
   assert.equal(health.mode,'multiplayer');assert(health.worldId);assert.equal(health.basePath,'/~333/japan');
   assert.equal(health.build,'2026-10-28-shared-1');
  });
  await t.test('raw index defaults to multiplayer without server injection',async()=>{
   const response=await fetch(base+'/index.html'),html=await response.text();
   assert.equal(response.status,200);assert(html.includes("new URLSearchParams(location.search).get('mode')!=='solo'"));
   assert(!html.includes('window.RAKUGAKI_MULTIPLAYER=true;'));
  });
  await t.test('HTML setup guide opens through the deployed prefix',async()=>{
   const response=await fetch(base+'/START_HERE.html');
   assert.equal(response.status,200);assert(response.headers.get('content-type').includes('text/html'));
   const guide=await response.text();assert(guide.includes('npm ci --ignore-scripts'));assert(guide.includes('proxy_set_header Upgrade'));
  });
  let first,second;
  await t.test('different accounts see the same spawned unit over WebSocket',async()=>{
   async function connect(){
    const response=await fetch(base+'/api/session');const session=await response.json();
    assert.equal(session.worldId,health.worldId);
    const ws=new WebSocket(base.replace('http:','ws:')+'/ws',{headers:{Cookie:response.headers.get('set-cookie').split(';')[0]}});
    sockets.push(ws);await new Promise((resolve,reject)=>{ws.once('open',resolve);ws.once('error',reject)});
    const ready=next(ws,m=>m.type==='ready');ws.send('{"type":"init"}');
    assert.equal((await ready).worldId,health.worldId);return {ws,session};
   }
   first=await connect();second=await connect();assert.notEqual(first.session.accountId,second.session.accountId);
   let reply=next(first.ws,m=>m.type==='teamResult');first.ws.send('{"type":"selectTeam","team":37}');assert((await reply).ok);
   const city=world.sim().cities.find(c=>c.owner===37&&!c.home);
   const png=new PNG({width:8,height:8});png.data.fill(255);const image='data:image/png;base64,'+PNG.sync.write(png).toString('base64');
   const art=next(second.ws,m=>m.type==='art');reply=next(first.ws,m=>m.type==='summonResult');
   first.ws.send(JSON.stringify({type:'summon',team:37,role:'melee',pixels:8,cityId:city.id,image}));
   const spawned=await reply;assert(spawned.ok);assert.equal((await art).unitId,spawned.id);
   const state=await next(second.ws,m=>m.type==='state'&&m.unitBuffer.some((id,i)=>i%21===0&&id===spawned.id));
   assert.equal(state.worldId,health.worldId);assert.deepEqual(state.ownedUnits,[]);
  });
  await t.test('a second server cannot bind against the same DATA_DIR',()=>{
   const code=`process.env.DATA_DIR=${JSON.stringify(dir)};const w=require(${JSON.stringify(path.resolve(__dirname,'../server.cjs'))});try{w.server.listen(0,'127.0.0.1');process.exit(2)}catch(e){console.log(e.code);process.exit(e.code==='WORLD_ALREADY_RUNNING'?0:1)}`;
   const child=spawnSync(process.execPath,['-e',code],{encoding:'utf8',timeout:20000});
   assert.equal(child.status,0,child.stderr);assert(child.stdout.includes('WORLD_ALREADY_RUNNING'));
   assert(fs.existsSync(path.join(dir,'server.lock')));
  });
 }finally{
  for(const socket of sockets)socket.terminate();await world.close();
  assert(!fs.existsSync(path.join(dir,'server.lock')));fs.rmSync(dir,{recursive:true,force:true});
 }
});
