'use strict';
const fs=require('node:fs'),path=require('node:path'),zlib=require('node:zlib');
const target=path.resolve('public');
fs.mkdirSync(target,{recursive:true});
const filename='rakugaki-node18-compatible.zip';
const files=['index.html','server.cjs','package.json','README.md','tests/integration.test.cjs','tests/security.test.cjs','tests/refactor.test.cjs','tests/aura.test.cjs','tests/multiplayer.test.cjs','IMPLEMENTATION.md','SIMPLIFICATION.md','COMMAND_UI.md','AURA_FIX.md','MULTIPLAYER_FIX.md','NODE18_COMPATIBILITY.md','START_HERE.html','.env.example','.gitignore','buildzip.cjs'];
for(const file of fs.readdirSync('validation').sort())if(/\.(cjs|json)$/.test(file))files.push('validation/'+file);
if(fs.existsSync('package-lock.json'))files.push('package-lock.json');
function crc32(buf){
 let v=0xffffffff;
 for(const b of buf){v^=b;for(let i=0;i<8;i++)v=(v>>>1)^((v&1)?0xedb88320:0)}
 return (v^0xffffffff)>>>0;
}
const records=[],central=[];let offset=0;
for(const file of files){
 const input=fs.readFileSync(file),name=Buffer.from('rakugaki-multiplayer/'+file,'utf8');
 const compressed=zlib.deflateRawSync(input,{level:9}),crc=crc32(input);
 const local=Buffer.alloc(30);local.writeUInt32LE(0x04034b50,0);local.writeUInt16LE(20,4);
 local.writeUInt16LE(8,8);local.writeUInt32LE(crc,14);
 local.writeUInt32LE(compressed.length,18);local.writeUInt32LE(input.length,22);local.writeUInt16LE(name.length,26);
 records.push(local,name,compressed);
 const entry=Buffer.alloc(46);entry.writeUInt32LE(0x02014b50,0);
 entry.writeUInt16LE(20,4);entry.writeUInt16LE(20,6);entry.writeUInt16LE(8,10);
 entry.writeUInt32LE(crc,16);entry.writeUInt32LE(compressed.length,20);entry.writeUInt32LE(input.length,24);
 entry.writeUInt16LE(name.length,28);entry.writeUInt32LE(offset,42);
 central.push(entry,name);offset+=local.length+name.length+compressed.length;
}
const directory=Buffer.concat(central),end=Buffer.alloc(22);
end.writeUInt32LE(0x06054b50,0);end.writeUInt16LE(files.length,8);end.writeUInt16LE(files.length,10);
end.writeUInt32LE(directory.length,12);end.writeUInt32LE(offset,16);
const archive=Buffer.concat([...records,directory,end]);
fs.writeFileSync(path.join(target,filename),archive);
const homepage='<!doctype html><html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>らくがき列島大戦｜マルチプレイ版</title></head><body style="font-family:system-ui;margin:3rem auto;padding:1.5rem;max-width:700px"><h1>らくがき列島大戦</h1><p>マルチプレイ版の検証用ZIPです。自前のNode.jsサーバーに導入するためのファイルをまとめています。</p><p><a href="/'+filename+'" download>ZIPをダウンロード</a></p><p>ZIP内のREADME.mdに起動手順があります。公開版のゲームは変更していません。</p></body></html>';
fs.writeFileSync(path.join(target,'index.html'),homepage);
console.log('ZIP CREATED',filename,archive.length,'bytes',files.length,'files');
